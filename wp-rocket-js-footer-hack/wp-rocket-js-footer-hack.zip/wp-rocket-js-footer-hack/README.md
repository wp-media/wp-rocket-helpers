# WP Rocket | JS Footer Hack

Injects a custom JavaScript tag before closing body tag.

🚧&#160;&#160;**ADVANCED CUSTOMIZATION, HANDLE WITH CARE!**

📝&#160;&#160;**Manual code edit required before use!**

You will need to replace `http://example.com/example.js` with your custom JavaScript URL.

To be used with:
* any setup where JS minification is enabled

Last tested with:
* WP Rocket 2.8.x
* WordPress 4.6.x
