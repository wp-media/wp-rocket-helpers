# Plugin Name: WP Rocket | Cache Status Resync

Synchronizes the cache table with the cache folder to keep the info current after each automatic cache purge
Hooks into rocket_after_automatic_cache_purge


Last tested with:
* WP Rocket {3.18.x}
* WordPress {6.8.x}
