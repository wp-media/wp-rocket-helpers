# WP Rocket | Events Calendar Unminify

Programmatically deactivates minification for events posts, events archives, events taxonomy pages, and posts/pages containing events shortcodes.

To be used with:
* [Events Calendar](https://wordpress.org/plugins/the-events-calendar/)

Last tested with:
* Events Calendar 4.2.x
* WP Rocket 2.8.x
* WordPress 4.6.x
