# WP Rocket | Disable Page Caching for Attachment Pages

Disables WP Rocket’s page cache file generation on WordPress Attachment pages while preserving other optimization features.

To be used with:
* any setup

Last tested with:
* WP Rocket 3.0.x
* WordPress 4.9.x
