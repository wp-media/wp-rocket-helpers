# Deactivate WooCommerce Refresh Cart Fragments Cache

Deactivate the WP Rocket feature that caches WooCommerce Refresh Cart Fragments.

Documentation:
* [{Docs title here}]({Docs URL here})

To be used with:
* WooCommerce

Last tested with:
* WP Rocket {3.1.x}
* WordPress {4.9.x}
