<ol class="needler">
    <li>
        <div class="col"><span class="status <?php echo file_needler('wp_head()', $theme_dir.'/header.php');?>"></span></div>
        <div class="col">PHP <strong>wp_head()</strong> present at theme/header.php?</div>
    </li>

    <li>
        <div class="col"><span class="status <?php echo file_needler('wp_footer()', $theme_dir.'/footer.php');?>"></span></div>
        <div class="col">PHP <strong>wp_footer()</strong> present at theme/footer.php?</div>
    </li>
</ol>