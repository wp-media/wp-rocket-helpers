# WP Rocket | Remove Toolbar Menu

Removes the WP Rocket menu from the WordPress toolbar (admin bar).

To be used with:
* any setup

Last tested with:
* WP Rocket 3.0.x
* WordPress 4.9.x
