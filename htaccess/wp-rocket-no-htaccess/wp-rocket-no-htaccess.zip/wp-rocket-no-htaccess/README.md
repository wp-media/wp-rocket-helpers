# WP Rocket | No .htaccess

Completely disable the use of .htaccess

Documentation:
* [{Docs title here}]({Docs URL here})

To be used with:
* any setup where WP Rocket does not have the permissions to write into .htaccess.

Last tested with:
* WP Rocket 3.2.x
* WordPress 5.0.x
