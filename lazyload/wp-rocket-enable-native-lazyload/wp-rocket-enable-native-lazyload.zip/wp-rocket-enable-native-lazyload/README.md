# WP Rocket | Enable Native Lazyload

This helper plugin will enable native lazyload for browsers which support it.

WP Rocket's lazyload feature will be used on browsers which don't support native lazyload.