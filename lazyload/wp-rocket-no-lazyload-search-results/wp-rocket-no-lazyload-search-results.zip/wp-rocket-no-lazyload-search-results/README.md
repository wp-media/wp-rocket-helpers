# WP Rocket | No LazyLoad On Search Results

Disables LazyLoad on search result pages.

To be used with:
* any setup where LazyLoad is active, but should not be applied on search result pages.

Last tested with:
* WP Rocket 3.2.x
* WordPress 5.0.x
