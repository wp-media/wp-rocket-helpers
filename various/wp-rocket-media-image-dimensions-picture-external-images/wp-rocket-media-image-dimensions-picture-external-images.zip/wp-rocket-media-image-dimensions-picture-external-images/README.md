# WP Rocket | Image Dimensions for <picture> and external images

Disables / Enables Add Missing Image Dimensions for <picture> and external images

📝&#160;&#160;**Manual code edit required before use!**

Remove the "//" at the begining of the line for the feature you want to use.

To be used with:
* any setup where you want to disable or enable Add Missing Image Dimensions for <picture> and external images

Last tested with:
* WP Rocket 3.8.x
* WordPress 4.8.x
