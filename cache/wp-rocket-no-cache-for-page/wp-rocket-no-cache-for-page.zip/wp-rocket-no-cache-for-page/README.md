# WP Rocket | Disable Page Caching For Specific Pages

Disables WP Rocket’s page cache file generation on specific pages while preserving other optimization features.

📝 **Manual code edit required before use!**

Search for EDIT THIS and add the page ID's you want to exclude to the array as detailed in the inline comment.

To be used with:
* any setup

Last tested with:
* WP Rocket 3.0.x
* WordPress 4.9.x
