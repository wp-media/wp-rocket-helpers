# WP Rocket | Remove X-Powered-By: WP Rocket from headers

This helper plugin removes WP Rocket’s x-powered-by signature from the response headers.  

Last tested with:
* WP Rocket 3.8.7
* WordPress 5.7
