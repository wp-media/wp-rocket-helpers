# WP Rocket | No LazyLoad for Essential Grid

Disables WP Rocket’s LazyLoad feature on pages with Essential Grid.

To be used with:
* [Essential Grid](https://www.themepunch.com/portfolio/essential-grid-wordpress-plugin/)

Last tested with:
* Essential Grid 2.0.x
* WP Rocket 2.8.x
* WordPress 4.6.x
