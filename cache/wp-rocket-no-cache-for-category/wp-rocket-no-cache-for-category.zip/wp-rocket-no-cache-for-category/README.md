# WP Rocket | Disable Page Caching For Posts under a category

Disables WP Rocket’s page cache file generation on specific pages or posts while preserving other optimization features.

📝 **Manual code edit required before use!**

Search for 'excluded',  and add the category slug you want to exclude.
You can duplicate the line 26 as needed if you want to exclude more categories

To be used with:
* any setup

