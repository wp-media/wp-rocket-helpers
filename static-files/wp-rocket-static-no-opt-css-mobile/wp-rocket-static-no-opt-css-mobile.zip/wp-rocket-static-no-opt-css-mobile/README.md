# WP Rocket | No Optimized CSS Delivery on Mobile

This plugin disables _Optimize CSS delivery_ programmatically (Loads CSS asynchronously & Remove Unused CSS) only for mobile devices.

To be used with:
* any setup where _Mobile Cache_ and _Separate cache files for mobile devices_ are enabled

Last tested with:
* WP Rocket 3.6
* WordPress 5.4.x
