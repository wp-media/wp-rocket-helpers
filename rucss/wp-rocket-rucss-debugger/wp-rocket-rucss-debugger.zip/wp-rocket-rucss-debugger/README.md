# WP Rocket | WP Rocket - RUCSS Debugger

A debugging tool for Remove Unused CSS. 
It creates a menu entry at WordPress Admin Dashboard > Tools > RUCSS Debugger

Documentation:
* https://docs.wp-rocket.me/article/1529-remove-unused-css

To be used with:
* As a debugging utility to monitor the status of Remove Unused CSS jobs and perform some actions.

Last tested with:
* WP Rocket 3.11.x
* WordPress 5-9.x
