# WP Rocket | Unload PSP Styles

Premium SEO Pack (PSP) loads their styles and scripts on all WordPress admin pages and this makes the interface of WP Rocket unusable. This helper plugin unloads PSP styles just on WP Rocket settings page. 

To be used with:
* Premium SEO Pack � Wordpress Plugin by AA-Team

Last tested with:
* Premium SEO pack 3.0
* WP Rocket 2.11.4
* WordPress 4.9.1

Changelog:
* 16 January 2018 - First release