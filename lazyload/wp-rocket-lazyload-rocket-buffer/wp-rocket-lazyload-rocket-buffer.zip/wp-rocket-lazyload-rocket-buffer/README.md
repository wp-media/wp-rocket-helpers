# WP Rocket | LazyLoad on rocket_buffer

Applies WP Rocket LazyLoad on rocket_buffer filter.

To be used with:
* any setup where WP Rocket LazyLoad is enabled for images. 

Last tested with:
* WP Rocket 3.2.x
* WordPress 5.0.x
