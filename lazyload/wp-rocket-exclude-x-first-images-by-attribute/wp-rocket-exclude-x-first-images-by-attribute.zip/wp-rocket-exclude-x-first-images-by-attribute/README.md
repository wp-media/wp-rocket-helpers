# WP Rocket | Exclude X First Images by Attribute

Exclude X first image by using an attribute.

📝&#160;&#160;**Manual code edit required before use!**

Edit before using.