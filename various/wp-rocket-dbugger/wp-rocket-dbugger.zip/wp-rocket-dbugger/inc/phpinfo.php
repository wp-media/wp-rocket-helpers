<h1>PHP Info</h1>
					
<iframe class="debugger" width="90%" height="600px" src="<?php echo $plugin_dir ?>/inc/info.php"></iframe>






