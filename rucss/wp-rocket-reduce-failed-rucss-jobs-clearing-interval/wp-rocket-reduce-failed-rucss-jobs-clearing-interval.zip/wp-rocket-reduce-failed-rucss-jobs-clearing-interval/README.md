# WP Rocket | Reduce failed RUCSS jobs clearing interval

Reduce failed RUCSS jobs clearing interval. This should only be used as a temporary fix.

To be used with:
* Any setup

Last tested with:
* WP Rocket 3.13.3