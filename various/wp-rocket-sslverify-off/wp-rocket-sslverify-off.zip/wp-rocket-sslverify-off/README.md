# WP Rocket | Disable SSL Certificate Validation

Disable SSL Certificate Validation for wp_remote_get requests in WP Rocket by setting sslverify to false. 

Documentation:
* [{Docs title here}]({Docs URL here})

To be used with:
* Any setup where preload fails with `cURL error 60: SSL certificate problem` and similar. 

Last tested with:
* WP Rocket 3.2.x
* WordPress 5.0.x
