# WP Rocket | Cache WP Rest API

Force WP Rocket to cache WP REST API

To be used with:
* Any setup where you want the WP REST API to be cached by WP Rocket.

Last tested with:
* WP Rocket 3.2.x
* WordPress 4.9.x
