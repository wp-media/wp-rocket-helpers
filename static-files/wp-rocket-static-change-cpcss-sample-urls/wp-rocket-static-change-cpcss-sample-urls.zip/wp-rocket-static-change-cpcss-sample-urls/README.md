# WP Rocket | Change Load CSS Asynchronously Sample URLs

Change Load CSS Asynchronously URL we use to build CPCSS for each post type.

Documentation: 

- [Change Load CSS Asynchronously sample URLs](https://docs.wp-rocket.me/article/1700-change-load-css-asynchronously-sample-urls)

📝&#160;&#160;**Manual code edit required before use!**

To be used with:
* Any setup where “Load CSS Asynchronously” is enabled and for some reason, CPCSS happens to pick up a URL that can't be processed.
