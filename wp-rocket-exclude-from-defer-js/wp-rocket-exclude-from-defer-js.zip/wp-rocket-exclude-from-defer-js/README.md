# WP Rocket | Exclude Files from Defer JS

Exclude specific files from defer JS option.

📝&#160;&#160;**Manual code edit required before use!**

Documentation:
* [Exclude files from defer JS](http://docs.wp-rocket.me/article/976-exclude-files-from-defer-js)

To be used with:
* any setup where “Load JS files deferred” is enabled

Last tested with:
* WP Rocket 2.10.x
* WordPress 4.7.x
