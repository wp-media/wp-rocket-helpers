# WP Rocket | EDD Cookie Cache

Sets a custom cookie for WP Rocket to generate cache files from.

To be used with:
* [Easy Digital Downloads (EDD)](https://wordpress.org/plugins/easy-digital-downloads/)

Last tested with:
* Easy Digital Downloads 2.6.x
* WP Rocket 2.8.x
* WordPress 4.6.x
