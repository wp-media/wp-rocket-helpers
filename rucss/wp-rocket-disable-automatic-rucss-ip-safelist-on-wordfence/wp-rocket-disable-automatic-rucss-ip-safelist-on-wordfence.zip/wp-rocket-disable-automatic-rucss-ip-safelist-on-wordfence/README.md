# WP Rocket | Disable automatic RUCSS IP safelist on Wordfence

Disable the automatic RUCSS IP safelist on Wordfence

To be used with:
* Any setup

Last tested with:
* WP Rocket 3.12.6.1