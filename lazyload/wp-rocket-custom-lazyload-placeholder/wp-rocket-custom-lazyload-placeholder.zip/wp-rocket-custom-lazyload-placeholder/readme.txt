=== WP Rocket - Custom LazyLoad Placeholder ===
Contributors: wp-rocket-helper
Tags: wp rocket, lazyload, placeholder
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Uses a transparent 1x1 GIF for the WP Rocket LazyLoad placeholder.

== Installation ==

1. Upload the plugin ZIP from Plugins > Add New > Upload Plugin.
2. Activate "WP Rocket - Custom LazyLoad Placeholder".
3. Clear the WP Rocket cache.

== Changelog ==

= 1.0.0 =
* Initial release.
