# WP Rocket | No LazyLoad for iframes on LeadPages

Disables LazyLoad for iframes/videos on _LeadPages_.

To be used with:
* LeadPages Connector plugin

Last tested with:
* LeadPages Connector 1.2.x
* WP Rocket 2.8.x
* WordPress 4.7.x
