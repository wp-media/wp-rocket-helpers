# WP Rocket | Change RSS Expires

Disables the browser caching for RSS

Additional editing not required

Last tested with:
* WP Rocket 3.3.4
* WordPress 5.2.1
