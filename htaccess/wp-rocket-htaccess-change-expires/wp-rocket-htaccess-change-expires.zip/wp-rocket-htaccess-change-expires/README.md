# WP Rocket | Change Expires

Edit or delete browser caching added by WP Rocket

Additional editing not required

Last tested with:
* WP Rocket 3.12.3.2
* WordPress 6.1.1
