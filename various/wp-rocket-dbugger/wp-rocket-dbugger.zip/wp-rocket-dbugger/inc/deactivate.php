<?php

//Deactivate plugin
deactivate_plugins('wp-rocket-dbugger/wp-rocket-d-bugger.php');

?>
<script>
window.location.href = '/wp-admin/plugins.php?s=D-bugger&plugin_status=all';
</script>