# WP Rocket Cache Feed

This add-on will allow caching of WordPress RSS Feeds.

Last tested with:
* WP Rocket 3.1.x
* WordPress 4.9.x
