# WP Rocket | Remove GZIP (mod_deflate) rules
---

Removes WP Rocket’s GZIP rules from .htaccess


You can install and activate this plugin as it is, however, you probably won’t have to keep all of .htaccess WP Rocket’s .htaccess rules removed, but only one or two. Follow the [documentation](https://docs.wp-rocket.me/article/110-resolve-500-internal-server-error) to find out which ones.

Last tested with:
* WP Rocket 3.4.0.3
* WordPress 5.2.3
