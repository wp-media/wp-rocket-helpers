<h1>Checks</h1>


<hr />

<h2>Theme</h2>
<?php  include('checks/theme.php'); ?>
<hr />
<h2>Server</h2>
<?php  include('checks/server.php'); ?>