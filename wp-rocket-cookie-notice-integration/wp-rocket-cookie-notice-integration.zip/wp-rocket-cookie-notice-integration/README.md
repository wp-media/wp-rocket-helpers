# WP Rocket | Cookie Notice Integration

A helper plugin for WP Rocket to integrate with Cookie Notice by dFactory.

To be used with:
* [Cookie Notice by dFactory](https://wordpress.org/plugins/cookie-notice/)

Last tested with:
* Cookie Notice by dFactory 1.2.40
* WP Rocket 2.11.4
* WordPress 4.9.2

Changelog:
* 17 January 2018 - First release