# WP Rocket | Desktop version of Critical CSS on Mobile

Makes sure that Desktop version of Critical CSS is beign used on mobiles when Separate Cache for Mobile Devices is enabled.

To be used with:
* any setup where _Mobile Cache_ and _Separate cache files for mobile devices_ are enabled

Last tested with:
* WP Rocket 3.6
* WordPress 5.4.x
