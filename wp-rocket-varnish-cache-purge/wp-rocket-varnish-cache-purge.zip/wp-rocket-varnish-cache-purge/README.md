# WP Rocket | Varnish Cache Purging

Forces Varnish cache purging with WP Rocket 2.6.8 to 2.6.16.

🚫&#160;&#160;**Deprecated for WP Rocket 2.7 and above.**
