# WP Rocket | Manipulate buffer

Searches for occurences of desired string in the buffer and replaces them with custom value

🚧 **ADVANCED CUSTOMIZATION, HANDLE WITH CARE!**
📝 **Manual code edit required before use!**

To specify string you want to add to the cache, please edit 29th line.
To change the string that should be replaced (</title> by default), please edit 44th line

To be used with:
* Any setup

Last tested with:
* WP Rocket 3.3.5.2
* WordPress 5.2.2
