# WP Rocket | Disable Preconnect to external domains

Disables the  Disable Preconnect to external domains and clears cache so pages are automatically updated.

**To reverse the changes,** simply deactivate the this helper plugin. 

Documentation:
* [Disable Preconnect to external domains](https://docs.wp-rocket.me/article/1869-preconnect-to-external-domains)

To be used with:
* Any setup where you want to disable the Critical Images Optimization.

Last tested with:
* WP Rocket 3.19
* WordPress 6.8



