# WP Rocket | UnLazyLoad LeadPages

Disables LazyLoad for iFrames/videos on _LeadPages_.

To be used with:
* LeadPages Connector plugin

Last tested with:
* LeadPages Connector 1.2.x
* WP Rocket 2.8.x
* WordPress 4.7.x
