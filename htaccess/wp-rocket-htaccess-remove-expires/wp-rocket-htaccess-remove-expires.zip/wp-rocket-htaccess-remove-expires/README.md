# WP Rocket | Remove GZIP (mod_deflate) rules

Removes WP Rocket’s expires rules from .htaccess.

Last tested with:

- WP Rocket 3.4.4.4
- WordPress 5.3.2