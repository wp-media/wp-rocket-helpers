# WP Rocket | Disable Cache and Optimizations on specific pages 

Using slugs, disable WP Rocket’s page cache and optimizations for specific URLs.

🚧&#160;&#160;**ADVANCED CUSTOMIZATION, HANDLE WITH CARE!**
📝 **Manual code edit required before use!**

Edit lines 25-27. Replace the slugs, add additional lines by duplication for more URLs slugs to exclude.



To be used with:
* any setup

Last tested with:
* WP Rocket 3.9
* WordPress 5.7
