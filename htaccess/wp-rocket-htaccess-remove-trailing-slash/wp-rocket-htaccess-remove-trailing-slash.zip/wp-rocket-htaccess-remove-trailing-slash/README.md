# WP Rocket | Remove Trailing Slash from URLs

Removes Trailing Slash from URLs.

To be used when:
* Permalinks should not include a trailing slash.

Last tested with:
* WP Rocket 3.7.4
* WordPress 5.5.1
