# WP Rocket | Reduce failed RUCSS jobs clearing interval

Reduce failed RUCSS jobs clearing interval

To be used with:
* Any setup

Last tested with:
* WP Rocket 3.13.3