# WP Rocket | Optimize WooCommerce Cart, Checkout, Account

Disables page caching for WooCommerce cart, checkout, and account pages, but keeps other optimization features applicable.

🚧&#160;&#160;**ADVANCED CUSTOMIZATION, HANDLE WITH CARE!**

To be used with:
* WooCommerce

Last tested with:
* WooCommerce 3.x
* WP Rocket 3.x
* WordPress 4.9.x
