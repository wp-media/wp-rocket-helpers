# WP Rocket | D-bugger

A debugging tool for WP Rocker Unused CSS
It creates a menu entry at WordPress Admin Dashboard > Tools > WPR D-bugger


To be used with:
* As a debugging utility to monitor the status of Remove Unused CSS, Preload, enable WPR_DEBUG_LOG, view some config files and server variables.

Last tested with:
* WP Rocket 3.12.x
* WordPress 6.x
