# WP Rocket | Disable Page Caching For Logged-In Users

Disables WP Rocket's page cache for logged-in users (User Cache) while preserving other optimization features.

To be used with:
* any setup where User Cache is enabled.

Last tested with:
* WP Rocket 3.4.x
* WordPress 5.2.x
