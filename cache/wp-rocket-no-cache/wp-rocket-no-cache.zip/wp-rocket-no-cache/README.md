# WP Rocket | Disable Page Caching

Disables WP Rocket’s page cache while preserving other optimization features.

Documentation:
* [Disable page caching](http://docs.wp-rocket.me/article/61-disable-page-caching)

To be used with:
* any setup

Last tested with:
* WP Rocket 2.9.x
* WordPress 4.7.x
