# WP Rocket | No LazyLoad for WooCommerce Product Images

Disables LazyLoad on WooCommerce main shop page, product category pages, product tag pages, and single product pages.

To be used with:
* WooCommerce

Last tested with:
* WooCommerce 2.6.x
* WP Rocket 2.8.x
* WordPress 4.6.x
