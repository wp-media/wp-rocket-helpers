# WP Rocket | Clear Preload Errors

Deletes the transient that stores preload errors on plugin activation. 

To be used with:
* any setup where WP Rocket preload errors are displayed even after fixing the cause. 

Last tested with:
* WP Rocket 3.2.x
* WordPress 5.0.x
