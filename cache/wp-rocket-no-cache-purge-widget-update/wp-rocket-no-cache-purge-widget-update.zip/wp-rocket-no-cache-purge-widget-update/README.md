# WP Rocket | Disable Cache Clearing On Widget Update

Disables WP Rocket cache clearing when a widget is updated.

🚧&#160;&#160;**ADVANCED CUSTOMIZATION, HANDLE WITH CARE!**

_When you activate this plugin, WP Rocket will no longer clear its cache when you update a widget. Clear WP Rocket cache manually if required._

To be used with:
* any setup

Last tested with:
* WP Rocket 3.2.x
* WordPress 5.0.x
