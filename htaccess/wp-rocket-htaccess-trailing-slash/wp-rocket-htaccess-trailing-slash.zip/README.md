# WP Rocket | Enforce Trailing Slash on URLs

Adds redirection rules to the .htaccess file in order to enforce trailing slash on URLs

Documentation:
* [Redirection to Enforce Trailing Slash on URLs]( http://docs.wp-rocket.me/article/131-redirection-to-enforce-trailing-slash-on-urls )

To be used with:
* any setup

Last tested with:
* WP Rocket 3.3.x
* WordPress 5.1.x
