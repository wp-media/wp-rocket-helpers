# WP Rocket | Cache Search Results

Enables caching for search result pages.

Documentation:
* [Caching the Search Page Results](http://docs.wp-rocket.me/article/29-caching-the-search-page-result)

To be used with:
* any setup

Last tested with:
* WP Rocket 2.11.x
* WordPress 4.9.x
