# WP Rocket | Disable WP Rocket's Emoji optimization

WP Rocket disables WordPress emoji automatically for all users. We also removed the UI from WP Rocket. This helper plugin will revert this optimization, and your website will use the Emoji file from WordPress.org instead of the default Emoji from vistor's browser.

Remember to clear the cache after activating this helper plugin

Documentation:
* [Auto-enable Disable Emoji](https://github.com/wp-media/wp-rocket/issues/3066)


Last tested with:
* WP Rocket 3.8.3
* WordPress 5.6
