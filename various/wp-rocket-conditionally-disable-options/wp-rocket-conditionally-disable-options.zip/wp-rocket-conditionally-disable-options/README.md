# WP Rocket | Conditionally disable options

Filter WP Rocket options based on any condition, in this case deactivating Delay JS, on Product single pages.
Here is the full list of all available filters: https://snippi.com/s/d9c2h4g
 

To be used with:
* WP Rocket 3.0 and newer

Last tested with:
* WP Rocket 3.9
* WordPress 5.7.2