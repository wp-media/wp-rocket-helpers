# WP Rocket | CPCSS Debug Helper

A WordPress plugin helping debug in CPCSS.

Documentation:
* [{Docs title here}]({Docs URL here})

To be used with:
* any setup that where `Optimize CSS delivery` (Critical Path CSS) is enabled in the File Optimization tab of WP Rocket. 

Last tested with:
* WP Rocket 3.2.x
* WordPress 5.0.x
