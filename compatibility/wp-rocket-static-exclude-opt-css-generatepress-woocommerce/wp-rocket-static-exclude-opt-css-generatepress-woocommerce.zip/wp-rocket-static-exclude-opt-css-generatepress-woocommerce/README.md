# WP Rocket | Exclude GeneratePress/WooCommerce Files from Async CSS

Exclude GeneratePress/WooCommerce CSS files from asynchronous loading - Optimize CSS Delivery.

Documentation:
* [GeneratePress and WooCommerce Issue](https://docs.wp-rocket.me/article/1399-generatepress-woocommerce)

To be used with:
* GeneratePress theme
* WooCommerce
* Optimize CSS Delivery and Mobile Caching

Last tested with:
* WP Rocket 3.23.x
* WordPress 7.x
