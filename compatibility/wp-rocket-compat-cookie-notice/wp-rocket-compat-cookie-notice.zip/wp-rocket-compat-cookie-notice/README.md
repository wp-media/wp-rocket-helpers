# WP Rocket | Cookie Notice Integration

Adds compatibility with Cookie Notice by dFactory to WP Rocket.

To be used with:
* [Cookie Notice by dFactory](https://wordpress.org/plugins/cookie-notice/)

Last tested with:
* Cookie Notice by dFactory 1.2.40
* WP Rocket 2.11.4
* WordPress 4.9.2
