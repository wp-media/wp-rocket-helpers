# WP Rocket | Exclude X First Images by Attribute

Exclude X first image by using an attribute.

📝&#160;&#160;**Manual code edit required before use!**

Edit before using.

To be used with:
* any setup where LazyLoad is active, but should not be applied on specified page types

Last tested with:
* WP Rocket 2.11.x
* WordPress 4.9.x
