# WP Rocket | Ignore Query Strings

Define query strings that should use the same set of cache.

{📝 **Manual code edit required before use!**}

You can add new parameter by copying existing line and changing its name in brackets (45th line and below). 
To remove existing parameters, please comment desired parameter like it's done with 'new_query_string'.

Documentation:

To be used with:
Any setup

Last tested with:
* WP Rocket {3.4-alpha1}
* WordPress {5.2.2}
