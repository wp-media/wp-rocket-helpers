# WP Rocket | Change CPCSS Sample URLs

Change CPCSS URL we use to build CPCSS for each post type

📝&#160;&#160;**Manual code edit required before use!**

Documentation:
* N/A

To be used with:
* any setup where “Load CSS files asynchronously” is enabled and for some reason, CPCSS happens to pick up a URL that can't be processed.

Last tested with:
* WP Rocket 2.10.x
* WordPress 4.7.x
