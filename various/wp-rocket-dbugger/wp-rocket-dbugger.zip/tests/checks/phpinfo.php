<h1>PHP Info</h1>

<iframe class="fileviewer" src="<?php echo $plugin_dir ?>/tests/info.php"></iframe>