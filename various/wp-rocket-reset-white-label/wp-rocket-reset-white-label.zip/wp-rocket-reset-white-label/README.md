# WP Rocket | Reset White Label

Resets White Label options to default values.

---

🔥 **CONSULT WP ROCKET’S SUPPORT** 🔥
🔥 **BEFORE YOU INSTALL THIS PLUGIN!** 🔥

---

To be used with:
* any setup where white-label modus was accidentally enabled and should be reset

Last tested with:
* WP Rocket 2.8.x
* WordPress 4.6.x
