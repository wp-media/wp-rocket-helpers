# WP Rocket | Unload PSP Styles

Premium SEO Pack (PSP) loads styles and scripts on all WordPress admin pages which makes WP Rocket’s settings page unusable. This helper plugin unloads PSP styles just on WP Rocket’s settings page.

To be used with:
* Premium SEO Pack WordPress Plugin by AA-Team

Last tested with:
* Premium SEO pack 3.0
* WP Rocket 2.11.4
* WordPress 4.9.1
