# WP Rocket | Reduce failed RUCSS jobs clearing interval

Reduce failed RUCSS jobs clearing interval. This should only be used as a temporary fix.

📝&#160;&#160;**Possible manual code edit required before use! If you're using a WP Rocket version before 3.16, set $is_after_atf_introduced to false.**

To be used with:
* Any setup

Last tested with:
* WP Rocket 3.16.x