WP Rocket | Disable Remove Unused CSS For Specific Pages or Posts

Disables Remove Unused CSS for Specific pages or posts

🚧  ADVANCED CUSTOMIZATION, HANDLE WITH CARE!

[Documentation:](https://docs.wp-rocket.me/article/1529-remove-unused-css)

+ Edit line 27 to exclude ids
+ Edit line 51 to exclude URLs
