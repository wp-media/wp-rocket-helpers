# WP Rocket | WooCommerce recently viewed products Integration

Create a specific cache for each value of woocommerce_recently_viewed cookie

To be used with:
* [YITH WooCommerce Recently Viewed Products](https://wordpress.org/plugins/yith-woocommerce-recently-viewed-products/)

Last tested with:
* YITH WooCommerce Recently Viewed Products 1.2.0
* WP Rocket 2.11.4
* WordPress 4.9.1

Changelog:
* 16 January 2018 - First release