# WP Rocket for DreamPress

This add-on will make WP Rocket 100% compatible with DreamPress hosting.

To be used with:
* DreamPress hosting

Last tested with:
* WP Rocket 2.10.4
* WordPress 4.8
