# WP Rocket | Preload mobile cache

By default, WP Rocket will preload the cache for desktops. Using this helper plugin the mobile cache will be preloaded instead.

The following features have to be enabled for this plugin to work:
* Mobile cache
* Separate cache for mobile devices

Cache for desktops will be created on the first visit of a page.