# WP Rocket | Enforce Trailing Slash on multisite

Adds the trailing slash for URLs on multisite setups.

To be used when:
* Permalinks should include a trailing slash.

Last tested with:
* WP Rocket 3.10.2
* WordPress 5.8
