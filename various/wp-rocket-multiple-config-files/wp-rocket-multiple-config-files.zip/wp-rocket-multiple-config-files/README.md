# WP Rocket | Multiple Config Files

Useful for cases where there are multiple URLs sharing the same filebase and multiple config files are needed.
