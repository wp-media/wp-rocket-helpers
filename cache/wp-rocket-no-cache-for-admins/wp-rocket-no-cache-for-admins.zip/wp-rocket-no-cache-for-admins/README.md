# WP Rocket | No Cache for Admins

Disable WP Rocket caching and optimizations for logged-in administrators.

To be used with:
* any setup where _User Cache_ is enabled, but administrators should get pages without caching and optimizations

Last tested with:
* WP Rocket 2.11.5
* WordPress 4.9.x
