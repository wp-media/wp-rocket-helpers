# WP Rocket | Disable Cache Clearing

Disables all of WP Rocket’s automatic cache clearing.

🚧&#160;&#160;**ADVANCED CUSTOMIZATION, HANDLE WITH CARE!**

_When you activate this plugin, WP Rocket will cache your pages, but will not clear the cache automtically when you make changes to them!_

Documentation:
* [Disable All Automatic Cache Clearing](http://docs.wp-rocket.me/article/137-disable-all-automatic-cache-clearing)

To be used with:
* any setup

Last tested with:
* WP Rocket 2.10.x
* WordPress 4.8.x
