<p>Hosting Provider: <?php echo get_hosting_provider(); ?></p>

<h2>PHP Info</h2>

<iframe class="fileviewer" src="<?php echo $plugin_dir ?>/tests/checks/info.php"></iframe>