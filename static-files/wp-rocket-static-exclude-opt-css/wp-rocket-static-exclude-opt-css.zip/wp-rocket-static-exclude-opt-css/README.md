# WP Rocket | Exclude Files from Async CSS

Exclude files from Optimize CSS Delivery option.

📝&#160;&#160;**Manual code edit required before use!**

Documentation:
* [Exclude files from async CSS](http://docs.wp-rocket.me/article/977-exclude-files-from-async-css)

To be used with:
* any setup where “Load CSS files asynchronously” is enabled

Last tested with:
* WP Rocket 2.10.x
* WordPress 4.7.x
